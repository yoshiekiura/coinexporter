<?php

return [

    'title'             		=> 'PRISONER TRANSFER',
    'copyright'					=> 'All Rights Reserved by'

];
