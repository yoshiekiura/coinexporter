

<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="welcome-dashboard">
	<div class="container">
    
  <?php echo $__env->make("layouts.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>


<div class="finish-table ptb-50">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="table_responsive_maas">                
            <table class="table table-hover">
                <thead>
                  <tr>
                    <th width="10%">Promoter’s ID</th>
                    <th width="10%">Campaign Type</th>
                    <th width="10%">Status</th>
                    <th width="10%">Social link </th>
                    <th width="20%">Submitted Proof</th>
                    <th width="10%">Time </th>
                    <th width="10%">Date </th>
                    <th width="10%">Reason</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $JobPaymentChecks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $JobPaymentCheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td align="left"><?php echo e($JobPaymentCheck->campaign_id); ?> </td>
                      <td><?php echo e($JobPaymentCheck->campaign_category_name); ?></td>
                      <?php if($JobPaymentCheck->tvl_status == 1): ?>
                      <td style="color: #ff7600;font-weight: 500;">Pending</td>
                      <?php elseif($JobPaymentCheck->tvl_status == 2): ?>
                      <td style="color: #1dbb00;font-weight: 500;">Confirmed </td>
                      <?php elseif($JobPaymentCheck->tvl_status == 3): ?>
                      <td style="color: #e11010;font-weight: 500;">Rejected</td>
                      <?php else: ?>
                      <td></td>
                      <?php endif; ?> 
                    <td><a href="#">Fb.harana.com</a></td>
                    <td><a href="#" class="click" data-bs-toggle="modal" data-bs-target="#proofModal">Click to view</a></td>
                    <td>12:23 UTC</td>
                    <td>12 June, 2022</td>
                    <td><a href="#" class="click" data-bs-toggle="modal" data-bs-target="#rejectModal">Click</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
         </div>

            </div>
        </div>
    </div>
</div>


<!--============================= cancelled =============================-->

<div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body can-modal">
        <img src="images/modal-bg.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Reason</h5>
        <p>Your cryptocurrency telegram group is full of bots and inactive</p>
      </div>
    <!--   <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>


<!-- ========================== Click Here======================= -->
<div class="modal fade" id="proofModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 514px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Submitted Proof</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <?php $ext = pathinfo($JobPaymentCheck->file_name, PATHINFO_EXTENSION);?>
       <?php if(($ext == 'mp4') || ($ext == 'mp3') || ($ext == 'pdf') || ($ext == 'gif')): ?>
        <iframe src="<?php echo BASEURL; ?>uploads/<?php echo e($JobPaymentCheck->file_name); ?>"></iframe>
        <?php elseif(($ext == 'png') || ($ext == 'PNG') || ($ext == 'jpg') || ($ext == 'JPG') || ($ext == 'jpeg') || ($ext == 'JPEG')): ?>
        <img src="<?php echo BASEURL; ?>uploads/<?php echo e($JobPaymentCheck->file_name); ?>">
        <?php else: ?>
        <?php if(empty($JobPaymentCheck->file_name)): ?>
        <p>N/A</p>
        <?php else: ?>
        <p><?php echo e($JobPaymentCheck->file_name); ?></p>
        <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<!-- <div class="modal fade" id="proofModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 514px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Why do you appeal this task to the admin? <br />Clearly state your reason?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <textarea rows="5" style="width: 100%;border-radius: 6px;border: 2px dashed #d5d5d5;padding: 10px 10px;" placeholder="write your reason here and submit to the admin. "></textarea>
      </div>
    </div>
  </div>
</div> -->

<!--============================= Scripts =============================-->
<a href="#" class="back-to-top" style="display: none;"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>

<script>            
jQuery(document).ready(function() {
	var offset = 220;
	var duration = 500;
	jQuery(window).scroll(function() {
		if (jQuery(this).scrollTop() > offset) {
			jQuery('.back-to-top').fadeIn(duration);
		} else {
			jQuery('.back-to-top').fadeOut(duration);
		}
	});
	
	jQuery('.back-to-top').click(function(event) {
		event.preventDefault();
		jQuery('html, body').animate({scrollTop: 0}, duration);
		return false;
	})
});
</script> 


<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH \\BINAYAK\COINEXPORTER\resources\views/history.blade.php ENDPATH**/ ?>