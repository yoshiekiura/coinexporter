<?php

namespace App\Http\Controllers;
use App\Models\JobSpace;
use Illuminate\Http\Request;

class DownloadfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $camp_id = $request->campaign_id;
        $jobSpace = JobSpace::select("job_spaces.file_name")->where('job_spaces.id', $camp_id)->first();
        $filename = $jobSpace->file_name;
        // $tempImage = tempnam(sys_get_temp_dir(), $filename);
        // $path = (BASEURL.'public/uploads');
        // copy($path, $tempImage);
        // return response()->download($tempImage, $filename);
        
            $path = (BASEURL.'uploads/'.$filename);
            return response()->download($path);
       
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
