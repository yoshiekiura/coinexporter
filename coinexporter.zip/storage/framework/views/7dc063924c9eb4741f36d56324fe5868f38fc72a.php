

<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="welcome-dashboard">
	<div class="container">
  <?php $__env->startSection('title', 'History'); ?>
  <?php echo $__env->make("layouts.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<style>
  .green{
	color: #1dbb00;font-weight: 500;
}
.red{
	color: #e11010;font-weight: 500;
}
.yellow{
	color: #ff7600;font-weight: 500;
}
</style>
<div class="container">
    <?php echo $__env->make("layouts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(Session::has('success')): ?>

    <div class="alert success-alert  alert-dismissible fade show" role="alert">
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php echo e(Session::get('success')); ?>

    </div>  
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close"></button>
    <?php echo e(Session::get('error')); ?>

    </div>
    <?php endif; ?>

    
</div>

<div class="finish-table ptb-50">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="table_responsive_maas">   
                <div id="successmsg"></div>             
            <table class="table table-hover">
                <thead>
                  <tr>
                    <th width="10%">Promoter’s ID</th>
                    <th width="10%">Campaign Type</th>
                    <th width="10%">Status</th>
                    <th width="10%">Social link </th>
                    <th width="20%">Submitted Proof</th>
                    <th width="10%">Time </th>
                    <th width="10%">Date </th>
                    <th width="10%">Reason</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $JobPaymentChecks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$JobPaymentCheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td align="left"><?php echo e($JobPaymentCheck->userid); ?> </td>
                      <td><?php echo e($JobPaymentCheck->campaign_category_name); ?></td>
                      <?php if($JobPaymentCheck->tvl_status == 'Pending'): ?>
                      <td class="yellow">
                      <span id="status<?php echo e($key+1); ?>">Pending</span></td>
                      <?php elseif($JobPaymentCheck->tvl_status == 'Approved'): ?>
                      <td class="green">
                      <span id="status<?php echo e($key+1); ?>">Approved</span> </td>
                      <?php elseif($JobPaymentCheck->tvl_status == 'Rejected'): ?>
                      <td class="red">
                      <span id="status<?php echo e($key+1); ?>">Rejected</span></td>
                      <?php else: ?>
                      <td></td>
                      <?php endif; ?> 
                    <td><a href="#">Fb.harana.com</a></td>
                    <td>
                      <?php if($JobPaymentCheck->proof_of_work == ''): ?>
                      <p>N/A</p>
                      <?php else: ?>
                    <a href="#" class="click" data-bs-toggle="modal" data-bs-target="#proofModal<?php echo e($key+1); ?>">Click to view</a>
                    <?php endif; ?>
                    </td>
                    <td><?php echo e(date("H:i", strtotime($JobPaymentCheck->created))); ?> UTC</td>
                    <td><?php echo e(date("d-M-Y", strtotime($JobPaymentCheck->created))); ?></td>
                    <td><a href="#" class="click" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo e($key+1); ?>">Click</a></td>
                    <?php if(($JobPaymentCheck->proof_of_work == '') || ($JobPaymentCheck->tvl_status == 'Approved')): ?>
                    <td></td>
                    <?php else: ?>
                    <td><!-- Example split danger button -->
                    <!-- Example single danger button -->
                    <div class="btn-group">
                      <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        Action
                      </button>
                      <ul class="dropdown-menu">
                        <li>
                        <input type="hidden" id="campaign_earnings<?php echo e($key+1); ?>" name="campaign_earnings" value="<?php echo e($JobPaymentCheck->campaign_earnings); ?>">
                          <input type="hidden" id="proof_of_work<?php echo e($key+1); ?>" name="proof_of_work" value="<?php echo e($JobPaymentCheck->proof_of_work); ?>">
                          <input type="hidden" id="campaign_id<?php echo e($key+1); ?>" name="campaign_id" value="<?php echo e($JobPaymentCheck->campaign_id); ?>">
                          <input type="hidden" id="user_id<?php echo e($key+1); ?>" name="user_id" value="<?php echo e($JobPaymentCheck->userid); ?>">
                        <a class="dropdown-item" href="#" onclick="status_change(this,<?php echo e($key+1); ?>)" data-status="Approved" id="job_done_status">Approve</a></li>
                        <li>
                        <a class="dropdown-item" href="#" onclick="reject_modal(<?php echo e($key+1); ?>)" data-status="Rejected" id="job_done_status">Reject</a></li>
                      </ul>
                    </div></td>   
                    <?php endif; ?>               
                  </tr>
             
                <!-- ========================== Click Here======================= -->
                <div class="modal fade" id="proofModal<?php echo e($key+1); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" style="max-width: 514px;">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Submitted Proof</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                      <?php $ext = pathinfo($JobPaymentCheck->proof_of_work, PATHINFO_EXTENSION);?>
                      <?php if(($ext == 'mp4') || ($ext == 'mp3') || ($ext == 'pdf') || ($ext == 'gif')): ?>
                        <iframe src="<?php echo BASEURL; ?>uploads/<?php echo e($JobPaymentCheck->proof_of_work); ?>"></iframe>
                        <?php elseif(($ext == 'png') || ($ext == 'PNG') || ($ext == 'jpg') || ($ext == 'JPG') || ($ext == 'jpeg') || ($ext == 'JPEG')): ?>
                        <img src="<?php echo BASEURL; ?>uploads/<?php echo e($JobPaymentCheck->proof_of_work); ?>">
                        <?php else: ?>
                        <?php if(empty($JobPaymentCheck->proof_of_work)): ?>
                        <p>N/A</p>
                        <?php else: ?>
                        <p><?php echo e($JobPaymentCheck->proof_of_work); ?></p>
                        <?php endif; ?>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>

                <!--============================= cancelled Reason =============================-->

              <div class="modal fade" id="rejectModal<?php echo e($key+1); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body can-modal">
                      <!-- <img src="<?php echo e(BASEURL); ?>images/modal-bg.png" alt=""> -->
                      <h5 class="modal-title" id="exampleModalLabel">Reason</h5>
                      <?php if($JobPaymentCheck->why_not_reason): ?>
                      <p><?php echo e($JobPaymentCheck->why_not_reason); ?></p>
                      <?php else: ?>
                      <p>N/A</p>
                      <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                    <button class="btn btn-primary" type="submit">Submit</button>
                  </div>
                  </div>
                </div>
              </div>
                <!--============================= Why Reject? =============================-->

                    <div class="modal fade" id="whyrejectModal<?php echo e($key+1); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:none;">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body can-modal">
                            <!-- <img src="<?php echo e(BASEURL); ?>images/modal-bg.png" alt=""> -->
                            <h5 class="modal-title" id="exampleModalLabel">Why Reject?</h5>
                            <input type="hidden" id="rejectkey" value="">
                            <textarea rows="5" style="width: 100%;border-radius: 6px;border: 2px dashed #d5d5d5;padding: 10px 10px;" id="whyreject<?php echo e($key+1); ?>" name="whyreject" placeholder="Reasor For Rejection."></textarea>
                          </div>
                          <div class="modal-footer">
                            <button class="btn btn-primary" type="button" onclick="status_change(this,<?php echo e($key+1); ?>)" data-status="Rejected">Submit</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
         </div>

            </div>
        </div>
    </div>
</div>






<!--============================= Scripts =============================-->
<a href="#" class="back-to-top" style="display: none;"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>

<script>            
jQuery(document).ready(function() {
	var offset = 220;
	var duration = 500;
	jQuery(window).scroll(function() {
		if (jQuery(this).scrollTop() > offset) {
			jQuery('.back-to-top').fadeIn(duration);
		} else {
			jQuery('.back-to-top').fadeOut(duration);
		}
	});
	
	jQuery('.back-to-top').click(function(event) {
		event.preventDefault();
		jQuery('html, body').animate({scrollTop: 0}, duration);
		return false;
	})
});
</script> 
<script>
  function reject_modal(key){
    $('#whyrejectModal'+key).modal('show');
  }

  function status_change(that,key){
  var status = $(that).data("status");
  var proof_of_work=$("#proof_of_work"+key).val();
  var campaign_earnings=$("#campaign_earnings"+key).val();
  var campaign_id=$("#campaign_id"+key).val();
  var user_id=$("#user_id"+key).val();
  var whyreject = $("#whyreject"+key).val();
 // alert(status);
  $.ajax({
    headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            url: "<?php echo e(route('history/approval')); ?>",
            type: 'POST',
            data: {
                'status': status,
                'campaign_earnings': campaign_earnings,
                'campaign_id': campaign_id,
                'user_id': user_id,
                'proof_of_work': proof_of_work,
                'whyreject':whyreject,
            },
            success: function(response) {
              //alert(response);
              $("#status"+key).html(status);
              if(status == "Approved")
              {
                $("table td:nth-child(3)").removeClass("yellow");
                $("table td:nth-child(3)").removeClass("red");
                $("table td:nth-child(3)").addClass("green");
              }
              else
              {
                $('#whyrejectModal'+key).modal('hide');
                $("table td:nth-child(3)").removeClass("yellow");
                $("table td:nth-child(3)").removeClass("green");
                $("table td:nth-child(3)").addClass("red");
              }
              
              $("#successmsg").html('<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button><strong>Status updated Successfully!</strong></div>');
            },
            error: function(response) {
                $("#successmsg").html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button><strong>Status not updated!</strong></div>');
            }
     });
    }
</script>

<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\coinexporter\resources\views/history.blade.php ENDPATH**/ ?>