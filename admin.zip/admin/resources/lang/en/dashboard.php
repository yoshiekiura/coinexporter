<?php

return [
    'title'             => 'Dashboard',
];
