<?php

return [
    'api_route_path'   => 'admin/api/log-reader',
    'view_route_path'  => 'admin/log-reader',
    'admin_panel_path' => 'admin/dashboard',
    'middleware'       => ['web', 'auth']
];