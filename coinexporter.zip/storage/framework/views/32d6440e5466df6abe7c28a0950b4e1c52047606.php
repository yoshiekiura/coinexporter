<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--  -->

<div class="container">
    <?php echo $__env->make("layouts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(Session::has('success')): ?>
    <div class="alert success-alert" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(Session::get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if($message = Session::get('error')): ?>
    <div class=" alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>
</div>

<!--  -->

<div class="welcome-dashboard">
    <div class="container">

        <?php echo $__env->make("layouts.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<div class="email-zip ptb-50">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-6">
                <div class="email-zip-title with-text">
                    <h3>Email/Zip Submit Sign Up</h3>
                    <ul>
                        <li>Work done:<span> 0/ <sup> <?php echo e($jobSpaceData[0]->promoters_needed); ?></sup></span></li>
                        <li>You will earn: <span> $ <?php echo e($jobSpaceData[0]->campaign_earning); ?></span></li>
                        <li>This task takes less than 3 minutes to finish</li>
                        <li>Campaign ID : <span> <?php echo e($jobSpaceData[0]->id); ?></span></li>
                        <li>Campaign Name : <span> <?php echo e($jobSpaceData[0]->campaign_name); ?> </span></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="email-zip-img">
                    <img src="images/jobdetails.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>


<div class="email-zip-box ptb-50">
    <div class="container">
        <form method="POST" action="<?php echo e(route('jobdetail.update')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="email-box-title">
                        <h4>You can accept this job if you are from</h4>
                        <p>THESE COUNTRIES ONLY! : <strong><?php echo e($jobSpaceCountry[0]->country_name); ?> </strong></p>
                    </div>
                    <div class="email-zip-list">
                        <ul>
                            <li><i class="far fa-user-hard-hat"></i>What is expected from workers?</li>
                            <div class="valuetd" style="padding: 8px; width: 100%;  white-space: pre-wrap;">
                                <?php echo e($jobSpaceData[0]->campaign_req); ?>

                            </div>
                            <li><i class="far fa-pager"></i>Required proof that task was finished?</li>
                            <div style="padding: 8px;  width: 100%; white-space: pre-wrap;">
                                <?php echo e($jobSpaceData[0]->campaign_proof); ?>

                            </div>
                            <li><i class="fal fa-badge-check"></i>Please select
                                <ul>
                                    <li><a href="<?php echo e(route('dashboard')); ?>">Not interested in this job</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="email-box-area">
                        <p>PROOF BOX - Enter the proof in the box below</p>
                        <h4 class="text-danger">* If a printscreen is asked, use theses free sites: <a href="https://snipboard.io/"> Snipboard</a> or <a href="https://prnt.sc/"> PRNT </a></h4>
                        <textarea rows="5" onresize="0" name="proofInstructionbox"></textarea>
                        <input type="hidden" name="campainEarning" value="<?php echo e($jobSpaceData[0]->campaign_earning); ?>">
                        <input type="hidden" name="campainUserId" value="<?php echo e($jobSpaceData[0]->user_id); ?>">
                        <input type="hidden" name="campainId" value="<?php echo e($jobSpaceData[0]->id); ?>">
                        <button>I confirm that I have follow instructions and complete this task!</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


<div class="dashboard-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                &copy; 2009 - 2022 Coin Exporter, All Rights Reserved
            </div>
        </div>
    </div>
</div>


<!--============================= Scripts =============================-->


<a href="#" class="back-to-top" style="display: none;"><i class="fa fa-arrow-up" aria-hidden="true"></i></a><?php /**PATH D:\wamp\www\coinexporter\resources\views/jobdetail.blade.php ENDPATH**/ ?>