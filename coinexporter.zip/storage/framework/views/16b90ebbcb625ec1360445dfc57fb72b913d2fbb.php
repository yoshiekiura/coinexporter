

    <?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  -->

    <div class="container">
        <?php echo $__env->make("layouts.alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(Session::has('success')): ?>
        <div class="alert success-alert" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>
        <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>
    </div>

    <!--  -->

    <div class="welcome-dashboard">
        <div class="container">

            <?php echo $__env->make("layouts.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <div class="finish-task">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="finish-title">
                        <h3>Welcome to “My Account” page</h3>
                        <h4>where you can update your profile to become Direct Marketer (Promoter), see transaction history, and some settings. Please, take note that most of what you do here require approval by CoinExporter</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="my-account-sec ptb-50">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="table_responsive_maas">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th width="20%">Links </th>
                                    <th width="40%">Social Channel Name</th>
                                    <th width="20%">Status</th>
                                    <th width="20%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td align="left">Personal Facebook </td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Personal Twitter</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Personal Tik Tok</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Personal Instagram</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Crypto Youtube</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Crypto Telegram Group/Channe</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Crypto Facebook Group/Page</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Crypto Instagram Page</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Crypto Twitter Page</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Crypto Blogging Site</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                                <tr>
                                    <td align="left">Crypto Discord group</td>
                                    <td></td>
                                    <td></td>
                                    <td><a href="#">Edit</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="profile-sec">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="p-box d-flex align-items-center">
                                    <div class="pro-img">
                                        <!-- <img src="images/prof-img.jpg"> -->
                                        <?php if(Auth::user()->profileImage != null || Auth::user()->profileImage != ''): ?>
                                        <img src="images/<?php echo e(Auth::user()->profileImage); ?>" alt="image">
                                        <?php else: ?>
                                        <img src="images/istockphoto.jpg" alt="image">
                                        <?php endif; ?>
                                    </div>
                                    <div class="pro-title">
                                        <p><?php echo e(Auth::user()->name); ?></p>
                                        <p>Email : <a href="mailto:<?php echo e(Auth::user()->email); ?>"><?php echo e(Auth::user()->email); ?></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 ">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="mid-pro-box">
                                        <div class="box1">
                                            <p>Country</p>
                                        </div>
                                        <div class="loc-pro">
                                            <p><?php echo e(Auth::user()->country); ?></p> <input type="checkbox" name="">
                                            <!-- <p>Nigeria</p> <input type="checkbox" name=""> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="mid-pro-box">
                                        <div class="box1">
                                            <p>IP Address</p>
                                        </div>
                                        <div class="loc-pro">
                                            <p>199.770.98.67</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <div class="pass-box">
                                <div class="row ">
                                    <div class="col-lg-12 col-md-6">
                                        <div class="pass-title">
                                            <label>PASTE YOUR BSC WALLET ADDRESS ONLY</label>
                                            <input type="text" name="" placeholder="Wallet Address">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6">
                                        <div class="pass-title">
                                            <label>CHANGE PASSWORD</label>
                                            <button data-bs-toggle="modal" data-bs-target="#changeModal">Click here to change password</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="transaction-sec ptb-50">
        <div class="container tran-bg">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-6">
                    <div class="tra-img">
                        <img src="images/tran-img4.png">
                    </div>
                </div>
                <div class="col-lg-8 col-md-6">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="tran-head">
                                <h4>Transsction History</h4>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="tran-title">
                                <label>Total Pending Balance</label>
                                <input type="text" name="" placeholder="$">
                            </div>
                            <div class="tran-title">
                                <label>Total Actual Balance</label>
                                <input type="text" name="" placeholder="$">
                            </div>
                            <div class="tran-title">
                                <label>Total Balances</label>
                                <input type="text" name="" placeholder="$">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="tran-title">
                                <label>Referral Bonus Balance</label>
                                <input type="text" name="" placeholder="$">
                            </div>
                            <div class="tran-title">
                                <label>Campaign Bonus Balance</label>
                                <input type="text" name="" placeholder="$">
                            </div>
                            <div class="tran-title">
                                <label>Total Withdrawn Amount</label>
                                <input type="text" name="" placeholder="$">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="dashboard-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    &copy; 2009 - 2022 Coin Exporter, All Rights Reserved
                </div>
            </div>
        </div>
    </div>


    <!-- ========================== change password modal======================= -->
    <div class="modal fade" id="changeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="max-width: 385px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <form action="<?php echo e(route('changepassword')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <img src="images/lock.png" style="max-width: 40%;">
                        <div class="pass-title" style="text-align: left;">
                            <label style="padding-bottom: 2px;">Old Password</label>
                            <input type="password" name="oldPassword" style="padding: 5px 7px;">
                        </div>
                        <div class="pass-title" style="text-align: left;">
                            <label style="padding-bottom: 2px;">New Password</label>
                            <input type="password" name="newPassword" style="padding: 5px 7px;">
                        </div>
                        <div class="pass-title" style="text-align: left;">
                            <label style="padding-bottom: 2px;">Confirm New Password</label>
                            <input type="password" name="ConfirmPassword" style="padding: 5px 7px;">
                        </div>
                        <div class="pass-title" style="margin-top: 30px; margin-bottom: 6px;">
                            <button class="btn-style-one" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!--============================= Scripts =============================-->
    <a href="#" class="back-to-top" style="display: none;"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>

    <script>
        jQuery(document).ready(function() {
            var offset = 220;
            var duration = 500;
            jQuery(window).scroll(function() {
                if (jQuery(this).scrollTop() > offset) {
                    jQuery('.back-to-top').fadeIn(duration);
                } else {
                    jQuery('.back-to-top').fadeOut(duration);
                }
            });

            jQuery('.back-to-top').click(function(event) {
                event.preventDefault();
                jQuery('html, body').animate({
                    scrollTop: 0
                }, duration);
                return false;
            })
        });
    </script>


<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\coinexporter\resources\views/myaccount.blade.php ENDPATH**/ ?>