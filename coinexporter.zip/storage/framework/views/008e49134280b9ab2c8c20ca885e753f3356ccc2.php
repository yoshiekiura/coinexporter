<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make("layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php $__env->startSection('title','About CoinExporter Token'); ?>
<?php echo $__env->make("layout.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="cointoken-sec ptb-50 dark-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="token-img">
                    <img src="<?php echo e(BASEURL); ?>images/about-token.png" alt="">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="token-content">
                    <h3 class="heading">About CoinExporter Token</h3>
                    <p class="text">CoinExporter Token ($COINEXPT) is the native token of the CoinExporter – a specialized and professional cryptocurrency Marketing Agency with incredible and solution-driven marketing activities. The native token provides the holders with earning opportunities that range from staking to 10% of the Agency’s monthly revenue and to mention but few.  The token will, in long time, provide much more benefits to the investors as CoinExporter gradually meeting the set goals. CoinExporter is built or launched on BSC Technology through Sphynexlabs. </p>
                </div>
            </div>
        </div>
    </div>
</section>


<!--============================= Footer =============================-->


<?php echo $__env->make("layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH \\BINAYAK\COINEXPORTER\resources\views/coinexporter_token.blade.php ENDPATH**/ ?>