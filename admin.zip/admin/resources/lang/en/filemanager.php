<?php

return [

    'index' => [
        'title' => 'File Manager',
    ],



    'breadcrumb' => [
        'index' => 'File Manager',
    ],

];