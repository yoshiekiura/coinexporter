<style>
    .error {
        color: #dc3545;
        font-size: 14px;
    }
</style>
<header>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="head-bar">
                    <div class="logo"><a href="#"><img src="images/coin-exporter.png" alt="" /></a></div>
                    <div class="menu">
                        <nav id="cssmenu" class="head_btm_menu">


                            <ul>
                                <?php if ($_SERVER['REQUEST_URI'] == '/') { ?>
                                    <li class="active"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <?php } else { ?>
                                    <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <?php }
                                if ($_SERVER['REQUEST_URI'] == '/about') { ?>
                                    <li class="active"><a href="<?php echo e(route('about')); ?>">About</a></li>
                                <?php } else { ?>
                                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                                <?php } ?>
                                <li><a href="#">Utilities</a>

                                    <ul> <?php if(Auth::check()): ?>
                                        <li><a href="<?php echo e(route('dashboard')); ?>">Campaign and Promotion</a>

                                        </li>
                                        <?php else: ?>
                                        <?php endif; ?>
                                        <li><a href="<?php echo e(route('404')); ?>">Staking</a></li>
                                        <li><a href="<?php echo e(route('404')); ?>">Affiliate Marketing</a></li>
                                        <li><a href="<?php echo e(route('404')); ?>">ER Services</a></li>
                                        <li><a href="<?php echo e(route('404')); ?>">Investment Call Support</a></li>
                                        <li><a href="<?php echo e(route('404')); ?>">Coins Fora</a></li>
                                        <li><a href="<?php echo e(route('404')); ?>">NFTs and NFTs Marketplace</a></li>
                                        <li><a href="<?php echo e(route('404')); ?>">P2P Marketing Service</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">CoinExporter Token</a>
                                    <ul>
                                        <li><a href="#">About CoinExporter Token</a></li>
                                        <li><a href="#">Tokenomics</a></li>
                                        <li><a href="#">Affiliate Marketing</a></li>
                                        <li><a href="#">Investors</a></li>
                                        <li><a href="#">Roadmap</a></li>
                                        <li><a href="#">Whitepaper</a></li>
                                        <li><a href="#">Team</a></li>
                                    </ul>
                                </li>
                                <?php if ($_SERVER['REQUEST_URI'] == '/faq') { ?>
                                    <li class="active"><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                                <?php } else { ?>
                                    <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                                <?php }
                                if ($_SERVER['REQUEST_URI'] == '/contact') { ?>
                                    <li class="active"><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                <?php } else { ?>
                                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                <?php } ?>



                        </nav>
                    </div>

                    <?php if(Auth::check()): ?>
                    
                <div class="dashboard_table_sec_top_right">
                    <div class="afterlogin-head">
                        <ul>
                            <li class="list">
                                <div class="drop_sec">
                                    <div class="dropdown">
                                        <a class="list_btn" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="far fa-bell"></i><span class="bg-dot"></span></a>
                                        <div class="dropdown-menu new_drop_cont" aria-labelledby="dropdownMenuLink">
                                            <ul>
                                                <li class="dropdown-item"><a href="#">Lorem Ipsum is simply dummy text ..</a></li>
                                                <li class="dropdown-item"><a href="#">Lorem Ipsum is simply dummy text ..</a></li>
                                                <li class="dropdown-item"><a href="#">Lorem Ipsum is simply dummy text ..</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="prof_img">
                                <div class="drop_sec">
                                    <div class="dropdown">
                                        <a class="list_btn" role="button" id="dropdownMenuLink2" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <!-- <img src="images/istockphoto.jpg" alt="" title=""> -->
                                            <?php if(Auth::user()->profileImage != null || Auth::user()->profileImage != ''): ?>
                                            <img src="images/<?php echo e(Auth::user()->profileImage); ?>" alt="profile">
                                            <?php else: ?>
                                            <img src="images/istockphoto.jpg" alt="profile">
                                            <?php endif; ?>
                                        </a>
                                        <div class="dropdown-menu new_drop_cont" aria-labelledby="dropdownMenuLink2">
                                            <div class="profile-header d-flex align-items-center">
                                                <div class="thumb-area">
                                                    <!-- <img src="images/istockphoto.jpg" alt="profile"> -->
                                                    <?php if(Auth::user()->profileImage != null || Auth::user()->profileImage != ''): ?>
                                                    <img src="images/<?php echo e(Auth::user()->profileImage); ?>" alt="profile">
                                                    <?php else: ?>
                                                    <img src="images/istockphoto.jpg" alt="profile">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="content-text">
                                                    <h6><?php echo e(Auth::check() ? Auth::user()->name : Auth::user()->email); ?></h6>
                                                    <p class="mb-0">Corportate Agent</p>
                                                </div>
                                            </div>
                                            <ul>
                                                <li class="dropdown-item"><a href="<?php echo e(route('editprofile')); ?>"><i class="fas fa-male"></i>Edit Profile</a></li>
                                                <li class="dropdown-item"><a href="#"><i class="fas fa-cogs"></i>Settings</a></li>
                                                <li class="dropdown-item"><a href="<?php echo e(route('myaccount')); ?>"><i class="fas fa-envelope"></i>My Account </a></li>
                                                <li class="dropdown-item"><a href="<?php echo e(route('editprofile')); ?>"><i class="fas fa-key"></i>Change Password</a></li>
                                                <li class="dropdown-item"><a href="<?php echo e(route('logout')); ?>"><i class="fas fa-power-off"></i>Sign Out</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <?php else: ?>
                <div class="head-btn">
                    <a href="#" class="login" data-bs-toggle="modal" data-bs-target="#signin-modal"><i class="fal fa-user"></i> Login</a>
                    <a href="#" data-bs-toggle="modal" data-bs-target="#register-modal"><i class="far fa-lock"></i> Register</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
</header>


<!--============================= Sign In Modal =============================-->


<div id="signin-modal" class="modal fade" tabindex="-1">
    <div class="modal-dialog loginpanle-modal">
        <div class="modal-content">
            <div class="modal-header">
                <img src="images/coin-exporter.png" alt="" />
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <!-- Session Status -->
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]]); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <!-- Validation Errors -->
            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
            <?php echo NoCaptcha::renderJs(); ?>


            <!-- <?php if($errors->has('g-recaptcha-response')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
            </span>
        <?php endif; ?> -->
            <form id="loginForm" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <h4>
                        Login in your account
                        <span>Use your credentials to access your account</span>
                    </h4>
                    <div id="errors-list"></div>
                    <ul>
                        <li>
                            <i class="far fa-user"></i>
                            <input type="email" class="form-control" name="email" :value="old('email')" required autofocus placeholder="Email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li>
                            <i class="far fa-lock"></i>
                            <input class="form-control" type="password" name="password" required autocomplete="current-password" placeholder="Password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>

                        <li>
                            <div class="row">
                                <div class="col-6 chkboxmain">
                                    <input id="Option5" type="checkbox">
                                    <label class="checkbox" for="Option5" name="remember"> Remember Me</label>
                                </div>
                                <div class="col-6 text-end"> <?php if(Route::has('password.request')): ?>
                                    <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a> <?php endif; ?>
                                </div>
                            </div>
                        </li>
                        
                        <li>
                            <button type="submit" class="btn">Sign In</button>
                        </li>
                        <li class="text-center dont-account">Don't have an account? <a href="#">Sign Up</a></li>

                    </ul>
                </div>
            </form>
            <!-- <?php if(count($errors)): ?>
            <div class="form-group">
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?> -->
        </div>
    </div>
</div>



<!-- ====================================Register Modal======================= -->

<div id="register-modal" class="modal fade" tabindex="-1">
    <div class="modal-dialog loginpanle-modal">
        <div class="modal-content">
            <div class="modal-header">
                <img src="images/coin-exporter.png" alt="" />
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <!-- Validation Errors -->
            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->

            <form id="regForm" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <h4>
                        Create Your account
                        <span>Setup a new account in a minute.</span>
                    </h4>
                    <ul>
                        <li>
                            <i class="far fa-user"></i>
                            <input type="text" class="form-control err" name="name" :value="old('name')" required autofocus placeholder="Enter Your Name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1" style="color:red"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li>
                            <i class="fas fa-envelope"></i>
                            <input type="text" class="form-control err" name="email" :value="old('email')" required placeholder="Enter Your Mail">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li>
                            <i class="far fa-lock"></i>
                            <input class="form-control err" type="password" name="password" required autocomplete="new-password" placeholder="Password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </li>
                        <li>
                            <i class="fas fa-flag"></i>
                            <select class="form-select form-control" aria-label="Default select example" name="country" id="country" required>
                                <option value="">Country</option>
                                <?php
                                $countries = App\Models\Country::all();
                                ?>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </li>
                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <!-- <li class="pb-2"><img src="images/captcha.jpg" class="w-75" alt=""/></li> -->
                        
                        <li>
                            <div class="row">
                                <div class="col-12 chkboxmain err">
                                    <input id="Option6" name="terms" type="checkbox" checked>
                                    <label class="checkbox" for="Option6"> I read and agreed to the CoinExporter privacy and terms and conditions.</label>
                                    <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </li>

                        <li>
                            <button type="submit" class="btn">Register Now</button>
                        </li>
                        <li class="text-center dont-account">Already have an account? <a href="#">Sign In</a></li>

                    </ul>
                </div>
                <!-- <?php if(count($errors)): ?>
            <div class="form-group">
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
            </div>
        <?php endif; ?> -->
        </div>

        </form>

    </div>
</div>
<script>
    $(document).ready(function() {
        $("#regForm").validate({
            // if(grecaptcha.getResponse() == "") {
            //   e.preventDefault();
            //   alert("You can't proceed!");
            // }
            rules: {
                name: "required",
                email: {
                    required: true,
                    email: true
                },
                password: "required",
                country: "required",
                //  captcha: "required",
                terms: "required",
            },
            messages: {
                name: "Name is required",
                email: {
                    required: "Email is Required",
                    email: "Enter Valid Email",
                    // remote: "This Email Already Exists",
                },
                password: "Password is required",
                country: "Please select the country",
                //  captcha: "Captcha is required",
                terms: "Terms & Conditions is required",
            }

        });
    });
</script>
<script>
    function loginsubmitForm() {
        // var response = grecaptcha.getResponse();
        // if(response.length == 0) {
        //     document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:red;">This field is required.</span>';
        //     return false;
        // }
        // return true;
    }

    // function verifyCaptcha() {
    //     document.getElementById('g-recaptcha-error').innerHTML = '';
    // }
</script>
<script>
    $(document).ready(function() {

        $("#loginForm").validate({
            // if(grecaptcha.getResponse() == "") {
            //   e.preventDefault();
            //   alert("You can't proceed!");
            // }
            rules: {
                email: {
                    required: true,
                    email: true
                },
                password: "required",
                //  captcha: "required",
            },
            messages: {
                email: {
                    required: "Email is Required",
                    email: "Enter Valid Email",
                },
                password: "Password is required",
                //  captcha: "Captcha is required",
            }

        });
    });
</script>
<!--========LogIn Through Ajax Call====-->
<script>
    $(function() {
        // handle submit event of form
        $(document).on("submit", "#loginForm", function() {
            var e = this;
            // change login button text before ajax
            $(this).find("[type='submit']").html("Signing In...");

            $.post($(this).attr('action'), $(this).serialize(), function(data) {

                $(e).find("[type='submit']").html("Sign In");
                if (data.status) { // If success then redirect to login url
                    window.location = data.redirect_location;
                }
            }).fail(function(response) {
                // handle error and show in html
                $(e).find("[type='submit']").html("Sign In");
                $(".alert").remove();
                var erroJson = JSON.parse(response.responseText);
                for (var err in erroJson) {
                    for (var errstr of erroJson[err])
                        $("#errors-list").append("<div class='alert alert-danger'>" + errstr + "</div>");
                }

            });
            return false;
        });
    });
</script><?php /**PATH D:\wamp\www\coinexporter\resources\views/layout/menu.blade.php ENDPATH**/ ?>